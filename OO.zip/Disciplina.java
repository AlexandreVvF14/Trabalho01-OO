import java.util.ArrayList;
import java.io.Serializable;

public class Disciplina implements Serializable{
    private static final long serialVersionUID = 1L;
    private String nome;
    private String codigo;
    private int cargaHoraria;
    private int capacidadeMaxima;
    private ArrayList<Aluno> alunosMatriculados;
    private ArrayList<Disciplina> preRequisitos = new ArrayList<>();

    public Disciplina(String nome, String codigo, int cargaHoraria, int capacidadeMaxima) {
        this.nome = nome;
        this.codigo = codigo;
        this.cargaHoraria = cargaHoraria;
        this.capacidadeMaxima = capacidadeMaxima;
        this.alunosMatriculados = new ArrayList<>();
    }

    public String getNome() {
        return nome;
    }

    public String getCodigo() {
        return codigo;
    }

    public void adicionarPreRequisito(Disciplina disciplina) {
        preRequisitos.add(disciplina);
    }

    public ArrayList<Disciplina> getPreRequisitos() {
        return preRequisitos;
    }

    public ArrayList<Aluno> getAlunosMatriculados() {
        return alunosMatriculados;
    }

    public void matricularAluno(Aluno aluno) {
        if (!alunosMatriculados.contains(aluno)) {
            alunosMatriculados.add(aluno);
            System.out.println("Aluno matriculado com sucesso!");
        } else {
            System.out.println("Aluno já matriculado nesta disciplina.");
        }
    }

    public boolean temVaga(){
        return alunosMatriculados.size() < capacidadeMaxima;
    }

    public int getCapacidadeMaxima() {
        return capacidadeMaxima;
    }

    @Override
    public String toString() {
        return nome + "\n" +
        "Código: " + codigo + "\n" +
        "Carga Horária: " + cargaHoraria + "\n" +
        "Alunos Matriculados: " + alunosMatriculados.size() + "\n";
    }
}