import java.util.ArrayList;

public class Trancamento {

    public static void menuTrancamento(ArrayList<Aluno> alunos) {
        System.out.println("Digite a matrícula do aluno: ");
        String matricula = System.console().readLine();

        Aluno aluno = buscarAlunoPorMatricula(alunos, matricula);

        if (aluno == null) {
            System.out.println("Aluno não encontrado.");
            return;
        }

        if (aluno.isTrancado()) {
            System.out.println("Aluno já está com o semestre trancado.");
            return;
        }

        System.out.println("+____________________________+");
        System.out.println("|       TRANCAMENTO          |");
        System.out.println("+____________________________+");
        System.out.println("| 1 - Trancar Semestre       |");
        System.out.println("| 2 - Trancar Disciplina     |");
        System.out.println("| 3 - Destrancar Semestre    |");
        System.out.println("| 0 - Voltar                 |");
        System.out.println("+____________________________+");
        System.out.print("Escolha uma opção: ");

        String escolha = System.console().readLine();

        switch (escolha) {
            case  "1":
                aluno.trancar();
                System.out.println("Semestre trancado com sucesso!");
                break;

            case "2":
                trancarDisciplina(aluno);
                break;

            case "3":
                aluno.destrancar();
                System.out.println("Semestre destrancado com sucesso!");
                break;

            case "0":
                System.out.println("Voltando ao Modo Aluno...");
                break;

            default:
                System.out.println("Opção inválida!");
        }

    }

    private static Aluno buscarAlunoPorMatricula(ArrayList<Aluno> alunos, String matricula) {
        for (Aluno aluno : alunos) {
            if (aluno.getMatricula().equals(matricula)) {
                return aluno;
            }
        }
        return null;
    }

    private static void trancarDisciplina(Aluno aluno) {
        ArrayList<Disciplina> disciplinas = aluno.getDisciplinasMatriculadas();

        if (disciplinas.isEmpty()) {
            System.out.println("Aluno não está matriculado em nenhuma disciplina.");
            return;
        }

        System.out.println("Disiciplinas matriculadas:");
        for (Disciplina d : disciplinas) {
            System.out.println("- " + d.getNome() + " (" + d.getCodigo() + ")");
        }

        System.out.print("Digite o código da disciplina que deseja trancar: ");
        String codigo = System.console().readLine();

        Disciplina disciplinaParaRemover = null;
        for (Disciplina d : disciplinas) {
            if (d.getCodigo().equalsIgnoreCase(codigo)) {
                disciplinaParaRemover = d;
                break;
            }
        }

        if (disciplinaParaRemover != null) {
            disciplinas.remove(disciplinaParaRemover);
            disciplinaParaRemover.getAlunosMatriculados().remove(aluno);
            System.out.println("Disciplina trancada com sucesso.");
        } else {
            System.out.println("Disciplina não encontrada na matrícula do aluno.");
        }
            
    }
}